# Installed by the geoip-lastlog package

. /etc/default/geoip-lastlog

[ true == $HUMANIZE ] && H='-H' || H='';

T='';
[ true == $DETECT_TOR ] && [ -f /var/lib/geoip-lastlog/exit-addresses ] && T='-t'

/usr/bin/geoip-lastlog -H $MAX_NUM $H $T
